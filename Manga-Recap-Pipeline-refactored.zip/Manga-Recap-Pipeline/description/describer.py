"""Step 4: describe what happens on each page, panel by panel.

One complete manga page (the numbered preview from step 3) is analyzed in a
single inference. The model replies with plain text:

    PANEL 1: ...
    PANEL 2: ...

which is then parsed into JSON. No detections.json is required or produced
by this step.
"""

from __future__ import annotations

import json
import re
import time
from pathlib import Path

import torch
from transformers import AutoModelForMultimodalLM, AutoProcessor

import config
from common.utils import list_images, move_to_device

PAGE_PROMPT = """\
Analyze the image visually.

For each panel, output:
PANEL N:
Characters: ...
Location: ...
Actions: ...

Rules:
- Describe every visible character or creature.
- Describe their visible appearance briefly.
- Describe where the scene takes place.
- Describe exactly what each character is visibly doing.
- Describe important visible objects when relevant.
- Use only information directly visible in the image.
- Do not guess names, identities, relationships, intentions, or story context.
- Do not invent events.
- Do not infer what happened before or after the scene.
- Only quote text that is clearly readable.
- Keep each field concise.
- No reasoning.
- No JSON.
"""

_PANEL_PATTERN = re.compile(r"^\s*PANEL\s+(\d+)\s*:\s*(.+?)\s*$", re.IGNORECASE | re.MULTILINE)


def load_describer():
    """Load the page-description model, processor, and run a warmup pass."""
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is not available.")

    torch.backends.cuda.matmul.allow_tf32 = False

    processor = AutoProcessor.from_pretrained(
        config.QWEN_MODEL_PATH,
        min_pixels=config.DESCRIPTION_MIN_PIXELS,
        max_pixels=config.DESCRIPTION_MAX_PIXELS,
    )
    model = AutoModelForMultimodalLM.from_pretrained(
        config.QWEN_MODEL_PATH,
        device_map="auto",
        dtype=torch.float16,
    ).eval()

    _warmup(processor, model)
    return processor, model


def _warmup(processor, model) -> None:
    """Initialize CUDA/model kernels before real inference."""
    messages = [{"role": "user", "content": [{"type": "text", "text": "Reply with exactly: OK"}]}]
    inputs = processor.apply_chat_template(
        messages,
        add_generation_prompt=True,
        tokenize=True,
        return_dict=True,
        return_tensors="pt",
        enable_thinking=config.DESCRIPTION_ENABLE_THINKING,
    )
    inputs = move_to_device(inputs, model.device)

    with torch.inference_mode():
        model.generate(**inputs, max_new_tokens=2, do_sample=False, use_cache=True)
    torch.cuda.synchronize()


def parse_response(response: str) -> dict[int, str]:
    """Extract PANEL N: description lines from the model's raw output."""
    descriptions: dict[int, str] = {}
    for match in _PANEL_PATTERN.finditer(response):
        panel_number = int(match.group(1))
        description = " ".join(match.group(2).split()).strip()
        if description:
            descriptions[panel_number] = description
    return descriptions


def describe_page(page_path: Path, processor, model) -> tuple[dict[int, str], float]:
    """Describe every visible panel on one page. Returns (descriptions, seconds)."""
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image", "image": str(page_path.resolve())},
                {"type": "text", "text": PAGE_PROMPT},
            ],
        }
    ]

    inputs = processor.apply_chat_template(
        messages,
        add_generation_prompt=True,
        tokenize=True,
        return_dict=True,
        return_tensors="pt",
        enable_thinking=config.DESCRIPTION_ENABLE_THINKING,
    )
    inputs = move_to_device(inputs, model.device)

    torch.cuda.synchronize()
    start = time.perf_counter()

    with torch.inference_mode():
        output_ids = model.generate(
            **inputs,
            max_new_tokens=config.DESCRIPTION_MAX_NEW_TOKENS,
            do_sample=False,
            num_beams=1,
            use_cache=True,
            eos_token_id=processor.tokenizer.eos_token_id,
            pad_token_id=processor.tokenizer.pad_token_id,
        )

    torch.cuda.synchronize()
    elapsed = time.perf_counter() - start

    generated = output_ids[0, inputs["input_ids"].shape[-1]:]
    response = processor.decode(generated, skip_special_tokens=True).strip()

    return parse_response(response), elapsed


def describe_chapter(chapter_output_dir: Path, processor, model) -> dict[str, list[dict]]:
    """Describe every numbered page preview of one chapter (step 3's output)."""
    preview_dir = chapter_output_dir / "page_previews"
    pages = list_images(preview_dir)

    results: dict[str, list[dict]] = {}
    for index, page_path in enumerate(pages, start=1):
        print(f"  [{index}/{len(pages)}] {page_path.name} ...", end=" ", flush=True)
        descriptions, elapsed = describe_page(page_path, processor, model)
        print(f"{len(descriptions)} panels, {elapsed:.2f}s")

        results[page_path.name] = [
            {"panel_number": number, "description": descriptions[number]}
            for number in sorted(descriptions)
        ]

    return results


def describe_manga(
    manga_output_dir: Path,
    chapter_dirs: list[Path],
    output_file: Path,
) -> None:
    """Load the description model once and describe every chapter."""
    print("Loading page-description model...")
    processor, model = load_describer()
    print("Model loaded.\n")

    all_results: dict[str, dict] = {}
    for chapter_dir in chapter_dirs:
        chapter_output_dir = manga_output_dir / chapter_dir.name
        print(f"Chapter: {chapter_dir.name}")
        all_results[chapter_dir.name] = describe_chapter(chapter_output_dir, processor, model)

    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(
        json.dumps(all_results, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(f"\nSaved descriptions to {output_file}")
