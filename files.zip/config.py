# Folder containing all page images of a chapter/volume, processed in filename order
INPUT_DIR = "test"
MODEL_PATH = "models/manga_panel_detector_fp32.pt"
OUTPUT_DIR = "output"

CONFIDENCE = 0.25
PANEL_CLASS_ID = 0

DARK_PIXEL_THRESHOLD = 100
DARK_RATIO_THRESHOLD = 0.05
TRIM_MARGIN = 2

JPEG_QUALITY = 95

# Manga is read right-to-left; set to False for Western left-to-right comics
READING_ORDER_RTL = True
# Minimum vertical overlap ratio for two panels to be considered part of the same row
ROW_OVERLAP_THRESHOLD = 0.5